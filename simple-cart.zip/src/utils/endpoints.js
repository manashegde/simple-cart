export const getPRoductsAPI="https://dummyjson.com/products"
export const loginAPI="https://dummyjson.com/auth/login"